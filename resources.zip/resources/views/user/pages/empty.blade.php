@extends('user.master')
@section('content')
<section class="header_text sub contentSection">
	<h4 class="text-center"><span>Empty</span></h4>
</section>
@endsection